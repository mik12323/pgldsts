<?php $__env->startSection('title', 'Register'); ?>

<?php $__env->startSection('content'); ?>

<style>
    .card-registration .select-input.form-control[readonly]:not([disabled]) {
    font-size: 1rem;
    line-height: 2.15;
    padding-left: .75em;
    padding-right: .75em;
    }
    .card-registration .select-arrow {
    top: 13px;
    }

</style>


<section class="h-100 bg-light">
    <div class="container py-5 h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col">
          <div class="card card-registration my-4">
            <div class="row g-0">
              <div class="col-xl-6 d-none d-xl-block">
                <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/img4.webp"
                  alt="Sample photo" class="img-fluid"
                  style="border-top-left-radius: .25rem; border-bottom-left-radius: .25rem;" />
              </div>
              <div class="col-xl-6">
                <div class="card-body p-md-5 text-black">
                  <h3 class="mb-5 text-uppercase"> registration form</h3>

                  <div class="row">
                    <div class="col-md-6 mb-4">
                      <div class="form-outline">
                        <input type="text" id="fname" class="form-control form-control-lg" />
                        <label class="form-label" for="fname">First name</label>
                      </div>
                    </div>
                    <div class="col-md-6 mb-4">
                      <div class="form-outline">
                        <input type="text" id="lname" class="form-control form-control-lg" />
                        <label class="form-label" for="lname">Last name</label>
                      </div>
                    </div>
                  </div>
                  <div class="form-outline mb-4">
                    <input type="text" id="email" class="form-control form-control-lg" />
                    <label class="form-label" for="email">Email ID</label>
                  </div>

                  

                  

                  <div class="row">
                    <div class="col-md-6 mb-4">

                      <select class="select">
                        <option value="1">Department</option>
                        <option value="2">Admin</option>
                        <option value="3">Labor</option>
                        <option value="4">Contract</option>
                      </select>

                    </div>
                    <div class="col-md-6 mb-4">

                      <select class="select">
                        <option value="1">Office</option>
                        <option value="2">Accounting</option>
                        <option value="3">BAC</option>
                        <option value="4">Cashier's Office</option>
                        <option value="5">PBO</option>
                        <option value="6">PEO</option>
                        <option value="7">PGO</option>
                        <option value="8">PPDO</option>
                        <option value="9">PTO</option>
                      </select>

                    </div>
                  </div>

                  <div class="form-outline mb-4">
                    <input type="password" id="password" class="form-control form-control-lg" />
                    <label class="form-label" for="password">Password</label>
                  </div>

                  <div class="form-outline mb-4">
                    <input type="password" id="cpassword" class="form-control form-control-lg" />
                    <label class="form-label" for="cpassword">Confirm Password</label>
                  </div>

                  <div class="form-outline mb-4">
                    <input type="text" id="dob" class="form-control form-control-lg" />
                    <label class="form-label" for="dob">Date of Birth <span style="font-size: 12px">MM-DD-YY</span></label>
                  </div>


                  <div class="d-flex justify-content-end pt-3">
                    <button type="button" class="btn btn-light btn-lg">Reset all</button>
                    <button type="button" class="btn btn-primary btn-lg ms-2">Register</button>
                  </div>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\file_tracking_system\resources\views/register.blade.php ENDPATH**/ ?>