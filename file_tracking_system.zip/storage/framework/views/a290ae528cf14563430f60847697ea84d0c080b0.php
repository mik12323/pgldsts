<?php $__env->startSection('title','Messages'); ?>

<?php $__env->startSection('content'); ?>

<section style="background-color: #eee;">
    <div class="container py-5">
      <div class="row">
        <div class="col">
          <div class="card mb-4">
            <div class="card-body text-center">
              <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava3.webp" alt="avatar"
                class="rounded-circle img-fluid" style="width: 150px;">
              <h5 class="my-3"><?php echo e($data['fname']); ?>  <?php echo e($data['lname']); ?></h5>
              <p class="text-muted mb-1"><?php echo e($data->department->department); ?></p>
              <p class="text-muted mb-4"><?php echo e($data->office->office); ?></p>
            </div>
          </div>


        <div class="col">
          <div class="card mb-4">
            <div class="card-body">
              <div class="row">
                <div class="col-sm-3">
                  <p class="mb-0">Full Name</p>
                </div>
                <div class="col-sm-9">
                  <p class="text-muted mb-0"><?php echo e($data['fname']); ?> <?php echo e($data['lname']); ?></p>
                </div>
              </div>
              <hr>
              <div class="row">
                <div class="col-sm-3">
                  <p class="mb-0">Email</p>
                </div>
                <div class="col-sm-9">
                  <p class="text-muted mb-0"><?php echo e($data['email']); ?></p>
                </div>
              </div>
              <hr>
              <div class="row">
                <div class="col-sm-3">
                  <p class="mb-0">Mobile Number</p>
                </div>
                <div class="col-sm-9">
                  <p class="text-muted mb-0"><?php echo e($data['phoneNumber']); ?></p>
                </div>
              </div>
              <hr>
              <div class="row">
                <div class="col-sm-3">
                  <p class="m-1">Date of Birth</p>
                </div>
                <div class="col-sm-1">
                  <p class="text-muted my-1"><?php echo e($data['dob']); ?></p>
                </div>
                <div class="col">
                    <a href="#" class="btn btn-warning btn-sm">Edit</a>
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
    <a href="<?php echo e(route('logout')); ?>" class="btn btn-danger">Logout</a>
  </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\file_tracking_system\resources\views/profile.blade.php ENDPATH**/ ?>