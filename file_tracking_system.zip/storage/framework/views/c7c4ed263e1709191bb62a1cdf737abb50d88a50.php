<?php $__env->startSection('title', 'Track a Document'); ?>

<?php $__env->startSection('content'); ?>

<div class="container text-center mt-5">
    
    <h4>Tracking Slip for By <?php echo e($projects->department->department); ?></h4>
    <table class="table table-bordered">
        <thead>
          <tr>
              <th scope="col">Reference No.</th>
            <th scope="col">Project Name</th>
            <th scope="col">Department</th>
            <th scope="col">Office</th>
            <th scope="col">Location</th>
            <th scope="col">Status</th>
          </tr>
        </thead>
        <tbody>
          <tr id="project">
            
            <td><?php echo e($projects->referenceNumber); ?></td>
            <td><?php echo e($projects->projectName); ?></td>
            <td><?php echo e($projects->department->department); ?></td>
            <td><?php echo e($projects->office->office); ?></td>
            <td><?php echo e($projects->location); ?></td>
            <td style="color:blue">Ongoing</td>

            

          </tr>
        </tbody>
    </table>
    <a href="<?php echo e(route('tracking-guest')); ?>" class="btn btn-primary btn-md">Track Again</a>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('master-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\file_tracking_system\resources\views/trackingProjectGuest.blade.php ENDPATH**/ ?>