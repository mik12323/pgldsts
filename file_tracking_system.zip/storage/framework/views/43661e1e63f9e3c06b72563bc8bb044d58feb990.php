<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset("css/main.css")); ?>">
    <title>Welcome to Provincial Capitol of Lanao del Sur</title>
    <?php $__env->startSection('title'); ?>
</head>
<body>


    <nav class="navbar navbar-expand-md bg-primary navbar-dark">
        <div class="container">
            <a href=# class="navbar-brand">
                <img class="logo" src="img/logo.png" alt="">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navMenu">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a href="#" class="nav-link">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link">Tracking</a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link">Messages</a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link">Profile</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>


    <section class="bg-dark text-light text-center p-5">
        <div class="container">
            <h2>You can <span style="color:rgb(213, 216, 16)">track</span> documents here</h2>
            <a href="#" class="btn btn-primary">Track</a>
        </div>
    </section>
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

</body>
</html>




<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
<?php /**PATH C:\xampp\htdocs\file_tracking_system\resources\views/welcome.blade.php ENDPATH**/ ?>