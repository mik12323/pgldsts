<?php $__env->startSection('title', 'Track a Document'); ?>

<?php $__env->startSection('content'); ?>


<h2>tracking</h2>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\file_tracking_system\resources\views/track.blade.php ENDPATH**/ ?>