<?php $__env->startSection('title',' Files'); ?>

<style>
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}
</style>

<?php $__env->startSection('content'); ?>


<div class="container mt-5 justify-content-center">
    <h4>Projects for work</h4>
    <table class="table table-bordered">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Department</th>
            <th scope="col">Project Name</th>
            <th scope="col">Reference No.</th>
            <th scope="col">Location</th>
            <th scope="col">Time in</th>
            <th scope="col">Time out</th>
            <th scope="col">Status</th>
          </tr>
        </thead>
        <tbody>
            
          <tr id="project">
                <th scope="row"><?php echo e($filesWork->id); ?></th>
                <td><?php echo e($filesWork->department); ?></td>
                <td><?php echo e($filesWork->filename); ?></td>
                <td><?php echo e($filesWork->referenceNumber); ?></td>
                <td><?php echo e($filesWork->location); ?></td>
                <td id="timeInDisplay"><button class="btn btn-success btn-sm" id="timeInButton">Time in</button></td>
                <td id="timeOutDisplay"><button disabled class="btn btn-danger btn-sm" id="timeOutButton">Time out</button></td>
                <td id="fileStatus"><?php echo e($filesWork->status); ?></td>
            

          </tr>
        </tbody>
      </table>
      <h4>Previous project</h4>
    <table class="table table-bordered">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Department</th>
            <th scope="col">Project Name</th>
            <th scope="col">Reference No.</th>
            <th scope="col">Location</th>
            <th scope="col">Time in</th>
            <th scope="col">Time out</th>
            <th scope="col">Status</th>
          </tr>
        </thead>
        
      </table>

</div>

<div class="container mt-5">
    <form action="<?php echo e(route('file-store')); ?>" method="POST">
        <?php if(Session::has('success')): ?>
        <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
        <?php endif; ?>
        <?php if(Session::has('fail')): ?>
        <div class="alert alert-danger"><?php echo e(Session::get('fail')); ?></div>
        <?php endif; ?>
        <?php echo csrf_field(); ?>

        <div class="col-auto mb-3">
            <label for="department">Department</label><br>
            <select name="department" class="select">
            <option value="">--Select Department--</option>
            <option value="Admin">Admin</option>
            <option value="Labor">Labor</option>
            <option value="Contract">Contract</option>
            </select>
            <span class="text-danger"><?php $__errorArgs = ['department'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>

        </div>
        <div class="col-auto mb-3">
            <label for="filename" class="form-label">File Name:</label>
            <input type="text" name="filename" class="form-control sm" value="<?php echo e(old('filename')); ?>">
            <div class="span text-danger"><?php $__errorArgs = ['filename'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
        </div>
        <div class="col-auto mb-3">
            <label for="referenceNumber" class="form-label">Reference Number:</label>
            <input type="number" name="referenceNumber" class="form-control sm" value="<?php echo e(old('referenceNumber')); ?>">
            <div class="span text-danger"><?php $__errorArgs = ['referenceNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
        </div>
        <div class="col-auto mb-3">
            <label for="location" class="form-label">Location:</label>
            <input type="text" name="location" class="form-control sm" value="<?php echo e(old('location')); ?>">
            <div class="span text-danger"><?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
        </div>
        <button class="btn btn-success btn-sm" type="submit">Add</button>
    </form>
</div>

<script>
    const timeOutButton = document.getElementById('timeOutButton');
    const timeInButton = document.getElementById('timeInButton');
    const timeInDisplay = document.getElementById('timeInDisplay');
    const timeOutDisplay = document.getElementById('timeOutDisplay');
    const fileStatus= document.getElementById('fileStatus');
    const project = document.getElementById('project');

    timeInButton.addEventListener("click", (e)=> {
        let today = new Date();
        let month = today.getMonth() +1;
        let year = today.getFullYear();
        let date = today.getDate();
        let current_date = `${year}-${month}-${date}`;

        let hours = today.getHours() - 12;
        let minutes = today.getMinutes();
        let seconds = today.getSeconds();
        let current_time = `${hours}:${minutes}:${seconds}`;

        timeInDisplay.innerText = current_date +" "+ current_time;
        // fileStatus.innerText = 'Ongoing';
        // fileStatus.style.color = 'blue';
        timeOutButton.disabled = false;

    });
    timeOutButton.addEventListener("click", (e)=> {
        event.preventDefault()


        let today = new Date();
        let month = today.getMonth() +1;
        let year = today.getFullYear();
        let date = today.getDate();
        let current_date = `${year}-${month}-${date}`;

        let hours = today.getHours() - 12;
        let minutes = today.getMinutes();
        let seconds = today.getSeconds();
        let current_time = `${hours}:${minutes}:${seconds}`;

        timeOutDisplay.innerText = current_date +" "+ current_time;

        fileStatus.style.color = 'red';
        // project.remove();

    });
</script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('master-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\file_tracking_system\resources\views/files.blade.php ENDPATH**/ ?>