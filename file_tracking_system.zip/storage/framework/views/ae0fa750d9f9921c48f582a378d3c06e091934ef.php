<?php $__env->startSection('title','Messages'); ?>

<?php $__env->startSection('content'); ?>
<h2>Messages</h2>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\file_tracking_system\resources\views/messages.blade.php ENDPATH**/ ?>