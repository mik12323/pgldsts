<?php $__env->startSection('title',' Projects'); ?>

<style>
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}
    #timeOutButton{
        display: none;
    }
</style>

<?php $__env->startSection('content'); ?>
<div class="container mt-5 p-5 justify-content-center bg-light">
    <h4>Projects Available for <?php echo e($data->department->department); ?></h4>
    <table class="table table-bordered bg-light text-center">
        <thead>
          <tr>
            <th scope="col">No.</th>
            <th scope="col">Reference No.</th>
            <th scope="col">Department</th>
            <th scope="col">Project Name</th>
            <th scope="col">Location</th>
            <th scope="col">Time in</th>
            <th scope="col">Time out</th>
            <th scope="col">Status</th>
          </tr>
        </thead>
        <tbody>
            <?php $i = '1';?>
            <?php $__currentLoopData = $projectsWork; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr id="project">
                <th scope="row"><?php echo e($i++); ?></th>
                <td><?php echo e($project->referenceNumber); ?></td>
                <td><?php echo e($project->department->department); ?></td>
                <td><?php echo e($project->projectName); ?></td>
                <td><?php echo e($project->location); ?></td>
                <td id="timeInDisplay"><a class="btn btn-success btn-sm" id="timeInButton">Time in</a></td>
                <td id="timeOutDisplay"><a class="btn btn-danger btn-sm" id="timeOutButton">Time out</a></td>
                <td id="projectStatus"><?php echo e($project->status); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </tr>
        </tbody>
      </table>
      <h4>Previous project</h4>
    <table class="table table-bordered bg-light text-center">
        <thead>
          <tr>
            <th scope="col">No.</th>
            <th scope="col">Reference No.</th>
            <th scope="col">Department</th>
            <th scope="col">Project Name</th>
            <th scope="col">Location</th>
            <th scope="col">Time in</th>
            <th scope="col">Time out</th>
            <th scope="col">Status</th>
          </tr>
        </thead>
        
      </table>
</div>





<script>
    const timeOutButton = document.getElementById('timeOutButton');
    const timeInButton = document.getElementById('timeInButton');
    const timeInDisplay = document.getElementById('timeInDisplay');
    const timeOutDisplay = document.getElementById('timeOutDisplay');
    const projectStatus= document.getElementById('projectStatus');
    const project = document.getElementById('project');

    timeInButton.addEventListener("click", (e)=> {
        let today = new Date();
        let month = today.getMonth() +1;
        let year = today.getFullYear();
        let date = today.getDate();
        let current_date = `${year}-${month}-${date}`;

        let hours = (today.getHours()===0)? 24:today.getHours();
        let minutes = today.getMinutes();
        let seconds = today.getSeconds();
        let current_time = `${hours}:${minutes}:${seconds}`;

        timeInDisplay.innerText = current_date +" "+ current_time;
        // projectStatus.innerText = 'Ongoing';
        // projectStatus.style.color = 'blue';
        timeOutButton.style.display = "block";

    });
    timeOutButton.addEventListener("click", (e)=> {
        event.preventDefault()


        let today = new Date();
        let month = today.getMonth() +1;
        let year = today.getFullYear();
        let date = today.getDate();
        let current_date = `${year}-${month}-${date}`;

        let hours = (today.getHours()===0)? 24:today.getHours();
        let minutes = today.getMinutes();
        let seconds = today.getSeconds();
        let current_time = `${hours}:${minutes}:${seconds}`;

        timeOutDisplay.innerText = current_date +" "+ current_time;

        projectStatus.style.color = 'red';
        // project.remove();

    });
</script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('master-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\file_tracking_system\resources\views/projects.blade.php ENDPATH**/ ?>