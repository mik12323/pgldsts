<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ActivitiesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //

        DB::table('activities')->insert([
            [
            'activityName'=>'POW, ABC, PR Alobs, DUPA & Plans Recommending for approval'
                ],[
            'activityName'=>'20% DF Charging'
                ],[
            'activityName'=>'Obligation Request Approval	'
                ],[
            'activityName'=>'Advertisement'
                ],[
            'activityName'=>'Opening of Bids'
                ],[
            'activityName'=>'Bid Evaluation	'
                ],[
            'activityName'=>'Post-Qualification	'
                ],[
            'activityName'=>'Approval of Resolution/ Issuance of Notice of Award'
                ],[
            'activityName'=>'Preperation & Approval of Contract (for by contract)'
                ],[
            'activityName'=>'Issuance of NTP/PO'
                ],[
            'activityName'=>'Preparation of Voucher/ Budget Appropriation'
                ],[
            'activityName'=>'Certification of Availability of Funds'
                ],[
            'activityName'=>'Voucher Approval'
                ],[
            'activityName'=>'Issuance of Check'
                ],[
            'activityName'=>'Approval of Check'
                ],[
            'activityName'=>'Issuance of Check Advice'
                ],[
            'activityName'=>'Receipt of Supplier/Contractor'
                ]
        ]);
    }
}
