@extends('master-layout')

@section('title','Messages')

@section('content')
<h2>Messages</h2>


@endsection
